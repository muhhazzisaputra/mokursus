<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'logoDesktop' => 'images/logo-primer.png',
    'logoMobile' => 'images/logo-sekunder.png',
    'menuItems' => [
        ['name' => 'Beranda', 'url' => '/', 'route' => 'home'],
        ['name' => 'Transaksi', 'url' => '/cek-pemesanan', 'route' => 'cek-pemesanan'],
        ['name' => 'Karya Alumni', 'url' => '/karya-alumni', 'route' => 'karya-alumni'],
        ['name' => 'Blog', 'url' => 'https://blog.ptcindonesia.co.id/', 'route' => ''],
        ['name' => 'Cek Sertifikat', 'url' => '/verifikasi-sertifikat', 'route' => 'verifikasi-sertifikat'],
        ['name' => 'Jadi Trainer', 'url' => 'https://docs.google.com/forms/d/e/1FAIpQLSdCiGXtNFHs6XYxZVoaB3l8aD89tkTadjGI2KFswrJ5EFLG8Q/viewform', 'route' => ''],
    ],
    'isSticky' => true
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'logoDesktop' => 'images/logo-primer.png',
    'logoMobile' => 'images/logo-sekunder.png',
    'menuItems' => [
        ['name' => 'Beranda', 'url' => '/', 'route' => 'home'],
        ['name' => 'Transaksi', 'url' => '/cek-pemesanan', 'route' => 'cek-pemesanan'],
        ['name' => 'Karya Alumni', 'url' => '/karya-alumni', 'route' => 'karya-alumni'],
        ['name' => 'Blog', 'url' => 'https://blog.ptcindonesia.co.id/', 'route' => ''],
        ['name' => 'Cek Sertifikat', 'url' => '/verifikasi-sertifikat', 'route' => 'verifikasi-sertifikat'],
        ['name' => 'Jadi Trainer', 'url' => 'https://docs.google.com/forms/d/e/1FAIpQLSdCiGXtNFHs6XYxZVoaB3l8aD89tkTadjGI2KFswrJ5EFLG8Q/viewform', 'route' => ''],
    ],
    'isSticky' => true
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<header class="<?php echo e($isSticky ? 'nav-glass sticky top-0 z-50' : 'nav-glass'); ?>">
    <div class="max-w-[1280px] mx-auto px-4 md:px-8 h-[64px] flex items-center justify-between gap-4">
        
        
        <a href="/" class="flex items-center flex-shrink-0">
            <img src="<?php echo e($logoMobile); ?>" alt="MoKursus" class="h-9 md:hidden" />
            <img src="<?php echo e($logoDesktop); ?>" alt="MoKursus" class="h-9 hidden md:block" />
        </a>

        
        <nav class="hidden lg:flex items-center gap-6">
            <?php $__currentLoopData = $menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($item['url']); ?>" 
               class="text-[13px] font-semibold <?php echo e(request()->routeIs($item['route']) ? 'text-ptc-blue border-b-2 border-ptc-blue' : 'text-slate-700 hover:text-ptc-blue'); ?> transition-colors">
                <?php echo e($item['name']); ?>

            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </nav>

        
        <div class="hidden lg:flex items-center gap-2">
            <a href="/login" class="text-[12px] font-semibold text-ptc-blue border border-ptc-blue/30 rounded-lg px-4 py-2 hover:bg-blue-50 transition-colors">
                Masuk
            </a>
            <a href="/login" class="text-[12px] font-bold text-white bg-ptc-gradient rounded-lg px-4 py-2 shadow-md shadow-ptc-blue/25 hover:opacity-90 transition-opacity whitespace-nowrap">
                Daftar Sekarang
            </a>
        </div>

        
        <div class="flex lg:hidden items-center gap-2">
            <a href="/login" class="text-[12px] font-bold text-white bg-ptc-gradient rounded-lg px-3 py-2 shadow-md hover:opacity-90 transition-opacity whitespace-nowrap">
                Daftar
            </a>
            <button id="hamburger" class="p-2 rounded-lg border border-slate-200 hover:bg-slate-50" onclick="toggleMobileMenu()">
                <svg width="20" height="20" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16"/>
                </svg>
            </button>
        </div>
    </div>

    
    <div id="mobile-menu" class="lg:hidden border-t border-slate-100 bg-white">
        <div class="max-w-[1280px] mx-auto px-4 py-4 flex flex-col gap-1">
            <?php $__currentLoopData = $menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="<?php echo e($item['url']); ?>" 
               class="py-2.5 px-3 text-[14px] font-semibold text-slate-700 hover:text-ptc-blue hover:bg-blue-50 rounded-lg transition-colors">
                <?php echo e($item['name']); ?>

            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <div class="border-t border-slate-100 mt-2 pt-3">
                <a href="/login" class="block py-2.5 px-3 text-[14px] font-semibold text-ptc-blue hover:bg-blue-50 rounded-lg transition-colors">
                    Masuk
                </a>
            </div>
        </div>
    </div>
</header>

<?php $__env->startPush('scripts'); ?>
<script>
    function toggleMobileMenu() {
        document.getElementById('mobile-menu').classList.toggle('open');
    }
    
    // Close mobile menu when clicking on a link
    document.querySelectorAll('#mobile-menu a').forEach(link => {
        link.addEventListener('click', () => {
            document.getElementById('mobile-menu').classList.remove('open');
        });
    });
</script>
<?php $__env->stopPush(); ?><?php /**PATH C:\laragon\www\mokursus\resources\views\components\header\navbar.blade.php ENDPATH**/ ?>