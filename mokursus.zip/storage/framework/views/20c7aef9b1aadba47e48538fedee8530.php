<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => 'Fitur Unggulan',
    'subtitle' => 'Semua yang Anda butuhkan untuk mengembangkan bisnis dalam satu platform terintegrasi',
    'features' => [
        [
            'icon' => '⚡',
            'title' => 'Cepat & Efisien',
            'description' => 'Proses yang cepat dan efisien untuk meningkatkan produktivitas tim Anda.',
            'color' => 'blue'
        ],
        [
            'icon' => '🔒',
            'title' => 'Keamanan Terjamin',
            'description' => 'Sistem keamanan berlapis untuk melindungi data berharga Anda.',
            'color' => 'purple'
        ],
        [
            'icon' => '🔗',
            'title' => 'Integrasi Mudah',
            'description' => 'Terintegrasi dengan berbagai platform dan tools populer.',
            'color' => 'green'
        ],
    ]
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => 'Fitur Unggulan',
    'subtitle' => 'Semua yang Anda butuhkan untuk mengembangkan bisnis dalam satu platform terintegrasi',
    'features' => [
        [
            'icon' => '⚡',
            'title' => 'Cepat & Efisien',
            'description' => 'Proses yang cepat dan efisien untuk meningkatkan produktivitas tim Anda.',
            'color' => 'blue'
        ],
        [
            'icon' => '🔒',
            'title' => 'Keamanan Terjamin',
            'description' => 'Sistem keamanan berlapis untuk melindungi data berharga Anda.',
            'color' => 'purple'
        ],
        [
            'icon' => '🔗',
            'title' => 'Integrasi Mudah',
            'description' => 'Terintegrasi dengan berbagai platform dan tools populer.',
            'color' => 'green'
        ],
    ]
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<section id="features" class="py-20 px-4 bg-white">
    <div class="container mx-auto max-w-6xl">
        <div class="text-center mb-12">
            <h2 class="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">
                <?php echo e($title); ?>

            </h2>
            <p class="text-gray-600 max-w-2xl mx-auto">
                <?php echo e($subtitle); ?>

            </p>
        </div>

        <div class="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            <?php $__currentLoopData = $features; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $feature): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="group p-6 bg-white rounded-xl shadow-md hover:shadow-xl transition-all duration-300 border border-gray-100 hover:border-<?php echo e($feature['color']); ?>-200">
                <div class="w-14 h-14 bg-<?php echo e($feature['color']); ?>-100 rounded-lg flex items-center justify-center mb-4 group-hover:bg-<?php echo e($feature['color']); ?>-600 transition-all duration-300 text-2xl">
                    <?php echo e($feature['icon']); ?>

                </div>
                <h3 class="text-xl font-semibold mb-2 text-gray-800"><?php echo e($feature['title']); ?></h3>
                <p class="text-gray-600 leading-relaxed"><?php echo e($feature['description']); ?></p>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</section><?php /**PATH C:\laragon\www\mokursus\resources\views\components\sections\features.blade.php ENDPATH**/ ?>