<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => 'Siap Meningkatkan Bisnis Anda?',
    'subtitle' => 'Bergabunglah dengan ribuan pengguna yang sudah merasakan manfaatnya',
    'buttonText' => 'Mulai Sekarang Gratis →',
    'buttonUrl' => '#',
    'gradient' => 'from-blue-600 to-purple-600'
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => 'Siap Meningkatkan Bisnis Anda?',
    'subtitle' => 'Bergabunglah dengan ribuan pengguna yang sudah merasakan manfaatnya',
    'buttonText' => 'Mulai Sekarang Gratis →',
    'buttonUrl' => '#',
    'gradient' => 'from-blue-600 to-purple-600'
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<section class="py-20 px-4 bg-gradient-to-r <?php echo e($gradient); ?>">
    <div class="container mx-auto max-w-4xl text-center">
        <h2 class="text-3xl sm:text-4xl font-bold text-white mb-4">
            <?php echo e($title); ?>

        </h2>
        <p class="text-blue-100 text-lg mb-8">
            <?php echo e($subtitle); ?>

        </p>
        <?php if (isset($component)) { $__componentOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9 = $attributes; } ?>
<?php $component = App\View\Components\Common\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Common\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($buttonUrl),'variant' => 'primary','size' => 'lg','class' => 'bg-white text-'.e(explode('-', $gradient)[1]).'-600 hover:bg-gray-100']); ?>
            <?php echo e($buttonText); ?>

         <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9)): ?>
<?php $attributes = $__attributesOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9; ?>
<?php unset($__attributesOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9)): ?>
<?php $component = $__componentOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9; ?>
<?php unset($__componentOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9); ?>
<?php endif; ?>
    </div>
</section><?php /**PATH C:\laragon\www\mokursus\resources\views\components\sections\cta.blade.php ENDPATH**/ ?>