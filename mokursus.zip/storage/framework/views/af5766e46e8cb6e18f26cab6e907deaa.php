<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames(([
    'title' => 'Solusi Terbaik untuk Bisnis Anda',
    'subtitle' => 'Tingkatkan produktivitas dan efisiensi bisnis Anda dengan platform modern yang kami sediakan.',
    'buttonText' => 'Mulai Gratis',
    'buttonUrl' => '#',
    'secondaryButtonText' => 'Demo Video',
    'secondaryButtonUrl' => '#',
    'imageUrl' => 'https://placehold.co/600x500/3B82F6/FFFFFF/png?text=Hero+Image',
    'stats' => [
        ['value' => '10K+', 'label' => 'Pengguna Aktif'],
        ['value' => '99%', 'label' => 'Kepuasan'],
        ['value' => '24/7', 'label' => 'Support'],
    ]
]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter(([
    'title' => 'Solusi Terbaik untuk Bisnis Anda',
    'subtitle' => 'Tingkatkan produktivitas dan efisiensi bisnis Anda dengan platform modern yang kami sediakan.',
    'buttonText' => 'Mulai Gratis',
    'buttonUrl' => '#',
    'secondaryButtonText' => 'Demo Video',
    'secondaryButtonUrl' => '#',
    'imageUrl' => 'https://placehold.co/600x500/3B82F6/FFFFFF/png?text=Hero+Image',
    'stats' => [
        ['value' => '10K+', 'label' => 'Pengguna Aktif'],
        ['value' => '99%', 'label' => 'Kepuasan'],
        ['value' => '24/7', 'label' => 'Support'],
    ]
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<section id="home" class="pt-32 pb-20 px-4 bg-gradient-to-br from-blue-50 via-white to-purple-50">
    <div class="container mx-auto max-w-6xl">
        <div class="flex flex-col lg:flex-row items-center gap-12">
            
            <div class="flex-1 text-center lg:text-left">
                <h1 class="text-4xl sm:text-5xl lg:text-6xl font-bold leading-tight">
                    <span class="bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                        <?php echo e($title); ?>

                    </span>
                </h1>
                <p class="text-gray-600 text-lg mt-6 mb-8 max-w-lg mx-auto lg:mx-0">
                    <?php echo e($subtitle); ?>

                </p>
                
                <div class="flex flex-col sm:flex-row gap-4 justify-center lg:justify-start">
                    <?php if (isset($component)) { $__componentOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9 = $attributes; } ?>
<?php $component = App\View\Components\Common\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Common\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($buttonUrl),'variant' => 'primary','size' => 'lg']); ?>
                        🚀 <?php echo e($buttonText); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9)): ?>
<?php $attributes = $__attributesOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9; ?>
<?php unset($__attributesOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9)): ?>
<?php $component = $__componentOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9; ?>
<?php unset($__componentOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9); ?>
<?php endif; ?>
                    
                    <?php if (isset($component)) { $__componentOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9 = $attributes; } ?>
<?php $component = App\View\Components\Common\Button::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('common.button'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\Common\Button::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['href' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($secondaryButtonUrl),'variant' => 'outline','size' => 'lg']); ?>
                        ▶️ <?php echo e($secondaryButtonText); ?>

                     <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9)): ?>
<?php $attributes = $__attributesOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9; ?>
<?php unset($__attributesOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9)): ?>
<?php $component = $__componentOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9; ?>
<?php unset($__componentOriginalc9ffd2270fff4ab5e3f02ffbfabaabe9); ?>
<?php endif; ?>
                </div>

                
                <div class="flex flex-wrap gap-8 mt-12 justify-center lg:justify-start">
                    <?php $__currentLoopData = $stats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $stat): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div>
                        <div class="text-2xl font-bold text-gray-900"><?php echo e($stat['value']); ?></div>
                        <div class="text-gray-500"><?php echo e($stat['label']); ?></div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            
            <div class="flex-1">
                <img src="<?php echo e($imageUrl); ?>" alt="Hero" class="rounded-2xl shadow-2xl w-full">
            </div>
        </div>
    </div>
</section><?php /**PATH C:\laragon\www\mokursus\resources\views\components\sections\hero.blade.php ENDPATH**/ ?>