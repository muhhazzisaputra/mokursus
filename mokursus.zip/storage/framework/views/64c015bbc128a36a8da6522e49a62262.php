<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title><?php echo $__env->yieldContent('title', 'MoKursus - Lembaga Kursus & Pelatihan Bersertifikat'); ?></title>
    
    
    <!-- <script src="https://cdn.tailwindcss.com"></script> -->
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    <link rel="preconnect" href="https://fonts.googleapis.com" />
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800;900&family=DM+Sans:ital,wght@0,400;0,500;1,400&display=swap" rel="stylesheet" />
    
    <?php echo $__env->yieldPushContent('styles'); ?>
</head>
<body>
    <!-- SPINNER -->
    <div id="page-spinner">
        <!-- <img src="logo-sekunder.png" alt="" style="height:40px;margin-bottom:4px;" onerror="this.style.display='none'"/> -->
        <div class="sring"></div>
        <div class="sdots"><span></span><span></span><span></span></div>
        <p style="font-size:13px;color:#94a3b8;font-weight:600;">Memuat halaman...</p>
    </div>

    
    <?php if (isset($component)) { $__componentOriginalb2351034fff8febe50a5c7b632e22b79 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalb2351034fff8febe50a5c7b632e22b79 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header.topbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('header.topbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalb2351034fff8febe50a5c7b632e22b79)): ?>
<?php $attributes = $__attributesOriginalb2351034fff8febe50a5c7b632e22b79; ?>
<?php unset($__attributesOriginalb2351034fff8febe50a5c7b632e22b79); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalb2351034fff8febe50a5c7b632e22b79)): ?>
<?php $component = $__componentOriginalb2351034fff8febe50a5c7b632e22b79; ?>
<?php unset($__componentOriginalb2351034fff8febe50a5c7b632e22b79); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal9d3074328e080c96d989f2095b34f194 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9d3074328e080c96d989f2095b34f194 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header.navbar','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('header.navbar'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9d3074328e080c96d989f2095b34f194)): ?>
<?php $attributes = $__attributesOriginal9d3074328e080c96d989f2095b34f194; ?>
<?php unset($__attributesOriginal9d3074328e080c96d989f2095b34f194); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9d3074328e080c96d989f2095b34f194)): ?>
<?php $component = $__componentOriginal9d3074328e080c96d989f2095b34f194; ?>
<?php unset($__componentOriginal9d3074328e080c96d989f2095b34f194); ?>
<?php endif; ?>

    
    <?php echo $__env->yieldContent('content'); ?>

    
    <?php if (isset($component)) { $__componentOriginale367d4420c39b248b34f4ae9d9b8f5ac = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginale367d4420c39b248b34f4ae9d9b8f5ac = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.sections.footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('sections.footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginale367d4420c39b248b34f4ae9d9b8f5ac)): ?>
<?php $attributes = $__attributesOriginale367d4420c39b248b34f4ae9d9b8f5ac; ?>
<?php unset($__attributesOriginale367d4420c39b248b34f4ae9d9b8f5ac); ?>
<?php endif; ?>
<?php if (isset($__componentOriginale367d4420c39b248b34f4ae9d9b8f5ac)): ?>
<?php $component = $__componentOriginale367d4420c39b248b34f4ae9d9b8f5ac; ?>
<?php unset($__componentOriginale367d4420c39b248b34f4ae9d9b8f5ac); ?>
<?php endif; ?>

    <?php echo $__env->yieldPushContent('scripts'); ?>
    <script>
        // SPINNER
        window.addEventListener("load",()=>{
        setTimeout(()=>{const s=document.getElementById("page-spinner");s.classList.add("hide");setTimeout(()=>{if(s.parentNode)s.parentNode.removeChild(s);},500);},900);
        });
    </script>
</body>
</html><?php /**PATH C:\laragon\www\mokursus\resources\views\layouts\app.blade.php ENDPATH**/ ?>